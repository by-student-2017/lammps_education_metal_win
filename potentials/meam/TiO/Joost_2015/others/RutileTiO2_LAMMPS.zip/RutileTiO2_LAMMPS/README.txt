This folder contains the input and output files for calculating the relaxed configuration of rutile TiO2
