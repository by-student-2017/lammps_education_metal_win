This folder contains the input and output files for calculating the relaxed configuration of a body centered cubic titanium structure with a single, octahedral oxygen interstitial
