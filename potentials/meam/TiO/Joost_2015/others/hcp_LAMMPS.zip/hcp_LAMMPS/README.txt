This folder contains the input and output files for calculating the relaxed configuration of a HCP titanium structure with a single, crowdion oxygen interstitial
