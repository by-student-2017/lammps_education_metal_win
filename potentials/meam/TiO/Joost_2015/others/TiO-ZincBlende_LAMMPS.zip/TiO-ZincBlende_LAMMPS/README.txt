This folder contains the input and output files for calculating the relaxed configuration of zinc blende TiO
