#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>

/* global structure parameters are defined here */

/* lattice constant */
double latcon;
/* fixed, equilibrium positions */
double *R_eq;
/* md simulation box */
double mdbox[3];
/* critical position with traffic light */
double xpass;


/* check accident, by condition x[i] < x[i-1] */
void accident(double R[], int n, FILE *fp)
{
   int i, j;

   for(i = 1; i < n; ++i) {
      j = i-1;
      if(R[i*3]>R[j*3]) {
         fprintf(fp, "accident happens between %d and %d \n",i,j);
      }
   }

   return;
}

/* count number, with x < xt */
int count(double R[], double xp, int n)
{
   int i, np;

   np = 0;
   for(i = 1; i < n; ++i) {
      if(R[i*3]<xp) {
         np = np + 1;
      }
   }

   return np;
}

/* generate structure */
void gen_struct(double mdbox[3], double R[], int n)
{
   int i;
   
   /* position */
   for(i = 0; i < n; ++i) {
      R[i*3  ] = -i*latcon;
      R[i*3+1] = 0.0;
      R[i*3+2] = 0.0;
   }

   /* md simulation box */
   mdbox[0] = n*latcon + 200.0;
   mdbox[1] = 10.0*latcon;
   mdbox[2] = 10.0*latcon;

   return;
}

/* output structure, viewed by OVITO */
void print_xyz(int step, double mdbox[3], double R[], double v[], int N, FILE *fp)
{
   int i;

   fprintf(fp, "ITEM: TIMESTEP\n");
   fprintf(fp, "%d\n", step);
   fprintf(fp, "ITEM: NUMBER OF ATOMS\n");
   fprintf(fp, "%d\n", N);
   fprintf(fp, "ITEM: BOX BOUNDS pp pp pp\n");
   fprintf(fp, "%g %g\n", 0.0, mdbox[0]);
   fprintf(fp, "%g %g\n", 0.0, mdbox[1]);
   fprintf(fp, "%g %g\n", 0.0, mdbox[2]);
   fprintf(fp, "ITEM: ATOMS id type x y z v_x v_y v_y\n");
   for(i = 0; i < N; ++i) {
      fprintf(fp, "%d %d %g %g %g %g %g %g\n", i+1, 1, R[i*3], R[i*3+1], R[i*3+2], v[i*3], v[i*3+1], v[i*3+2]); 
   }

   return;
}

void shift2center(double mdbox[3], double R[], int n)
{
   int i;
   double xc, yc, zc;

   xc = 0.0;
   yc = 0.0;
   zc = 0.0;
   for(i = 0; i < n; ++i) {
      xc += R[i*3+0];
      yc += R[i*3+1];
      zc += R[i*3+2];
   }
   xc /= (double)n;
   yc /= (double)n;
   zc /= (double)n;
   for(i = 0; i < n; ++i) {
      R[i*3+0] += 0.5*mdbox[0]-xc;
      R[i*3+1] += 0.5*mdbox[1]-yc;
      R[i*3+2] += 0.5*mdbox[2]-zc;
   }

   return;
}
