#include  <stdio.h>
#include  <stdlib.h>
#include  <math.h>
#include  <assert.h>

/* integration step size dt = h */
double h;
/* acceleration */
double a;

void force(double v[], double q[], int N, double F[]);

/* the lead car, with specified motion, starting or stopping */
/*void leadcar(double p[], double q[], int icar, double v1, double v2, double t0, int step)
{
  double t, v; 

  t = h*step;
  v = v2 + (v1-v2)*exp(-t/t0);
  p[icar*3+0] = v;

  return;
}
*/
/*void leadcar(double p[], double q[], int icar, double v1, double v2, double t0, int step)
{
  double t, v;

  t = h*step;
  if (t<=t0){
     v = v1 + ((v2-v1)/t0)*t;
  }else if (t>t0){
     v = v2;
  }
  p[icar*3+0] = v;

  return;
}
*/
void leadcar(double p[], double q[], int icar, double v1, double v2, double a, int step)
{
  double t, v, t0;

  t0 = (v2-v1) / a;
  assert(t0>0);

  t = h*step;
  if (t<=t0){
     v = v1 + a*t;
  }else if (t>t0){
     v = v2;
  }
  p[icar*3+0] = v;

  return;
}

/*	Perform a second-order symplectic step using the algorithm
		p- = p + h/2 f(p,q)
		q^ = q + h/m p-
		p^ = p- + h/2 f(p-,q^)
	where p,q are old values, p^,q^ are new values, and p- is
	the half-size intermediate value, f is force.  All of them
        are vectors of dimension n (the number of degrees of freedom).
        h is step size. The algorithm is also called velocity Verlet.
      	See, e.g., Frenkel & Smit.
*/

void Verlet(double p[], double q[], int n)
{
  double *f;
  int i;

  f = (double *) malloc((n)*sizeof(double));

  force(p, q, n/3, f);

  for(i = 0; i < n; ++i) {
    p[i] += 0.5*h*f[i];
  }

  force(p, q, n/3, f);

  for(i = 0; i < n; ++i) {
    q[i] += h*p[i];
    p[i] += 0.5*h*f[i];
  }

  return;
}
