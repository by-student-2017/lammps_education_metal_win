/* Molecular dynamics.

   By Jian-Sheng Wang, 9 December 2008
   Revised by Jin-Wu Jiang, for 1D chain, 13/09/15/Sun
   Simplified by Jin-Wu Jiang, for traffic flow, 31/12/19/Tue

   Important parameters and variables --
        p,q:  dynamical variables (velocity and position vectors). The
            i-th degree of freedom is at p[i], q[i], counting from 0. 
        h:  integration step size.
*/
#include  <stdio.h>
#include  <stdlib.h>
#include  <math.h>
#include  <assert.h>
#include  <time.h>

/* structure globals are defined in structure.c, md globals are defined
   in dynamic.c. We define here as extern. */

/* integration step size dt = h */
extern double h;
extern double a;
/* equilibrium positions */
extern double *R_eq;
extern double mdbox[3];
extern double xpass;

extern double latcon;
extern double latconf;
extern double tv;
extern double tr;

void Verlet(double p[], double q[], int n);
void gen_struct(double mdbox[3], double R[], int n);
void print_xyz(int step, double mdbox[3], double R[], double v[], int N, FILE *fp);
void shift2center(double mdbox[3], double R[], int n);
int count(double R[], double xt, int n);
void accident(double R[], int n, FILE *fp);
void leadcar(double p[], double q[], int icar, double v1, double v2, double a, int step);

int main(int argc, char **argv)
{
  double *p, *q;
  FILE *prompt_file, *in_file, *out_file, *fp, *fp2;
  int N, i, npass;
  int mdstep, nstep, ndump;
  double v1, v2;
  double d12;

  prompt_file = stdout;
  out_file = stdout;

  in_file = fopen("a.inp", "r");

  fprintf(prompt_file,"enter lattice constant latcon, and latconf [in meter] \n");
  fscanf(in_file, "%lf%lf", &latcon, &latconf);

  fprintf(prompt_file,"enter atom number for chain nx \n" );
  fscanf(in_file, "%d", &N);

  fprintf(prompt_file,"enter v1, v2, a \n");
  fscanf(in_file, "%lf%lf%lf", &v1, &v2, &a);

  fprintf(prompt_file,"enter relaxation time: tf, ts [in sec] \n");
  fscanf(in_file, "%lf%lf", &tv, &tr);

  fprintf(prompt_file,"enter MD step size h [in units of sec] \n");
  fscanf(in_file, "%lf", &h); 
  fprintf(prompt_file,"enter MD steps, simulation, dump, (nstep, ndump) \n");
  fscanf(in_file, "%d%d", &nstep, &ndump); 

  fclose(in_file);

  p = malloc(3*N*sizeof(double)); 
  q = malloc(3*N*sizeof(double));
  R_eq = malloc(3*N*sizeof(double));

  assert(p != NULL);
  assert(q != NULL);
  assert(R_eq != NULL);

  /* initial positions */
  gen_struct(mdbox, R_eq, N);
  /* set boundary condition */
  shift2center(mdbox, R_eq, N);
  xpass = R_eq[0*3+0] + 1.0;

  for(i = 0; i < 3*N; ++i) { 
     q[i] = R_eq[i];
  }

/* initial zero velocity */
  for(i = 0; i < N; ++i){
     p[i*3+0] = v1;
     p[i*3+1] = 0.0;
     p[i*3+2] = 0.0;
  }

  fp = fopen("data/xyz0.ovito", "w");
  print_xyz(0, mdbox, q, p, N, fp);
  fclose(fp);

  fp = fopen("data/xyz.ovito", "w");
  fp2 = fopen("data/result.dat", "w");
  fprintf(fp2, "# dumping data during md simulation\n");
  fprintf(fp2, "# time [sec], count, x2-x1 [meter]\n");
  for(mdstep = 0; mdstep < nstep; ++mdstep) {
     if(mdstep%ndump == 0){
        print_xyz(mdstep, mdbox, q, p, N, fp);
        npass = count(q, xpass, N);
	d12 = q[1*3+0] - q[0*3+0];
        fprintf(fp2, "%f %d %f\n", mdstep*h, npass, d12);
     }
     Verlet(p,q,3*N);
     leadcar(p, q, 0, v1, v2, a, mdstep);
     accident(q, N, out_file);
  }
  fclose(fp);
  fclose(fp2);
  fprintf(out_file, "# job done Sir! \n");

  fclose(out_file);
  return 0;
}
