/* Compute potential energy, force. */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

/* realaxation time for following car, velocity and distance */
double tv;
double tr;
/* space between neighboring cars */
double latconf;
const double alpha = 0.3;

void force(double v[], double q[], int N, double F[])
{
   int i, j;
   double Fx;
   double vec[3], vmod, d;
   double sign;

   for(i = 0; i < 3*N; ++i) {
      F[i] = 0.0;
   }
   /* force, Fi = - (vi-vj)^alpha/tf - (rij-r0)/ts */
   for(i = 1; i < N; ++i) {
      j = i-1;
      vec[0] = v[i*3+0] - v[j*3+0];
      vec[1] = v[i*3+1] - v[j*3+1];
      vec[2] = v[i*3+2] - v[j*3+2];
      if(vec[0]>0) {
         sign = -1.0;
      }
      else {
         sign = 1.0;
      }
      vmod = sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2]);
      d = pow(vmod, alpha);
      Fx = sign*d/tv;
/*      vec[0] = q[i*3+0] - q[j*3+0] - latconf;
      Fx += -vec[0]/tr;
*/
      F[i*3  ] = Fx;
   }

   /* first atom, no force */
   F[0] = 0.0;

   return;
}
